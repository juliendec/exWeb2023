module.exports = {
  ...require('prettier-airbnb-config'),
  printWidth: 100,
  arrowParens: 'always',
  bracketSpacing: true,
  trailingComma: 'all',
};
