module.exports = {
  ...require('prettier-airbnb-config'),
  printWidth: 120,
  arrowParens: 'always',
  bracketSpacing: true,
  trailingComma: 'all',
};
